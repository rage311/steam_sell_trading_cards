package Mojo::LoaderTest::C;

use Mojo::Base -base;

1;
